#include "Mailbox.h"
//Basic .cpp containing constructor/destructor for mailbox

Mailbox::Mailbox() {

}

Mailbox::~Mailbox() {

}
